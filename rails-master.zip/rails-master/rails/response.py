from webob import Response as WebobResponse


class Response(WebobResponse):
    """
    Extended response object.
    """
    pass
